package com.sourabh.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		SBU s = (SBU)ctx.getBean("sbu");
		s.displaySbu();
		ctx.close();

	}

}
