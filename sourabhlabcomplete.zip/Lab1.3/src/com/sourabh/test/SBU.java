package com.sourabh.test;

import java.util.List;

public class SBU {
	
	private int sbuId;
	private String sbuName;
	private String sbuHead;
	
	private List<Employee> list ;

	public List<Employee> getList() {
		return list;
	}
	public void setList(List<Employee> list) {
		this.list = list;
	}
	
	public SBU() {
		super();
	}
	public SBU(int sbuId, String sbuName, String sbuHead) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
	}
	public int getSbuId() {
		return sbuId;
	}
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	
	public void displaySbu()
	{
		System.out.println("Sbu details are : \nSBU id is "+this.getSbuId()+"\nSBU name is "+this.getSbuName()+"\nSBU head name is "+this.getSbuHead());
		System.out.println("Employee details are : ");
		System.out.println("================================");
		for(Employee e:list)
		{
			System.out.println(e);
			/*System.out.println("Employee Id is "+e.getAge());
			System.out.println("Employee Name is "+e.getEmployeeName());
			System.out.println("Employee Salary is "+e.getSalary());
			System.out.println("Employee BU is "+e.getBusinessUnit());
			System.out.println("Employee age is "+e.getAge());*/
		}
	}
	
	
}
