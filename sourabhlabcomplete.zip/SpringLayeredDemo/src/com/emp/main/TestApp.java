package com.emp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.emp.bean.Employee;
import com.emp.controller.EmployeeController;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.emp")
public class TestApp {

	public static void main(String[] args) {
		
		ApplicationContext ctx = SpringApplication.run(TestApp.class,args);
		EmployeeController controller = (EmployeeController)ctx.getBean("employeeController");
		Employee emp =new Employee();
		
		emp.setEmployeeId(1001);
		emp.setEmployeeName("Sourabh");
		
		controller.sendEmployee(emp);
		System.err.println("\n\n\n\nEmployee addeed successfully\n\n\n\n");

	}

}
