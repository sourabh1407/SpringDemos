package com.emp.dao;

import com.emp.bean.Employee;

public interface IEmployeeDao {
	
	public void addEmployee(Employee emp);
	
}
