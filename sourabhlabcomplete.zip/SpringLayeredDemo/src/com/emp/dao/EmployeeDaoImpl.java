package com.emp.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.emp.bean.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {
	
	Map<Integer,Employee> map = new HashMap<Integer,Employee>();
	
	
	
	public Map<Integer, Employee> getMap() {
		System.out.println(map);
		System.out.println("inside getMap()");
		return map;
	}



	public void setMap(Map<Integer, Employee> map) {
		this.map = map;
		System.out.println(map);
		System.out.println("inside setMap()");
	}



	@Override
	public void addEmployee(Employee emp) {
		map.put(emp.getEmployeeId(), emp);
		//System.out.println(map);
		//System.out.println("inside addEmployee()");
	}

}
