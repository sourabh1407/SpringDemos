package com.sourabh.sbu;

public class Employee {
	
	private int employeeId;
	private String employeeName;
	private double salary;
	private String businessUnit;
	private int age;
	
	private SBU sbu;
	
	
	
	public SBU getSbu() {
		return sbu;
	}
	
	public String getSbuDetails()
	{
		return ("SBU id  "+sbu.getSbuId()+"\nSBU Name "+sbu.getSbuName()+" \nSBU head "+sbu.getSbuHead());
	}
	
	public void setSbu(SBU sbu) {
		this.sbu = sbu;
	}
	public Employee() {
		super();
	}
	public Employee(int employeeId, String employeeName, double salary,
			String businessUnit, int age) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.businessUnit = businessUnit;
		this.age = age;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

	public void getEmployeeDetails()
	{
		System.out.println("Employee details are : ");
		System.out.println("================================");
		System.out.println("Employee Id is "+this.getAge());
		System.out.println("Employee Name is "+this.employeeName);
		System.out.println("Employee Salary is "+this.getSalary());
		System.out.println("Employee BU is "+this.getBusinessUnit());
		System.out.println("Employee age is "+this.getAge());
		System.out.println("Sbu details "+this.getSbuDetails());
	}
	
	
	
}
