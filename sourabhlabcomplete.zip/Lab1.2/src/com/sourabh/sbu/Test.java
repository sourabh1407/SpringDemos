package com.sourabh.sbu;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		Employee emp = (Employee)ctx.getBean("employee");
		emp.getEmployeeDetails();
		ctx.close();

	}

}
