package com.sourabh.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmplpoyee {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		Employee emp = (Employee)ctx.getBean("employee");
		emp.getEmployeeDetails();
		ctx.close();
	}

}
