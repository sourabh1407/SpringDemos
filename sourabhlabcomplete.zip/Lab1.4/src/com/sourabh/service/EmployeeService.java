package com.sourabh.service;

import java.util.HashMap;

import com.sourabh.bean.Employee;
import com.sourabh.dao.EmployeeDAO;
import com.sourabh.dao.IEmployeeDAO;

public class EmployeeService implements IEmployeeService {
	IEmployeeDAO ed ;
	@Override
	public Employee getEmployee(int employeeId) {
		return ed.getEmployee(employeeId);
	}
	@Override
	public void setEmployee(HashMap<Integer, Employee> hmap) {
		ed.setEmployee(hmap);
		
	}

}
