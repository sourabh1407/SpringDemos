package com.sourabh.service;

import java.util.HashMap;

import com.sourabh.bean.Employee;

public interface IEmployeeService {
	public Employee getEmployee(int employeeId);
	
	public void setEmployee(HashMap<Integer, Employee> hmap);
}
