package com.sourabh.collection;

import java.util.HashMap;

import com.sourabh.bean.Employee;

public class DBEmployee{
	
	public static HashMap<Integer, Employee> hmap = new HashMap<Integer,Employee>();
	Employee emp;
	
	public HashMap<Integer, Employee> getHmap() {
		/*emp = new Employee(1, "Sourabh", 45000);
		hmap.put(1, emp);
		emp = new Employee(2, "Gaurav", 95000);
		hmap.put(2, emp);
		emp = new Employee(3, "Rushi", 55000);
		hmap.put(3, emp);
		emp = new Employee(4, "Amrutha", 65000);
		hmap.put(4, emp);*/
		return hmap;
	}

	public void setHmap(HashMap<Integer, Employee> hmap2) {
		hmap = hmap2;
	}


	
	
	
	
}
