package com.sourabh.dao;

import java.util.HashMap;

import com.sourabh.bean.Employee;

public interface IEmployeeDAO {
	public Employee getEmployee(int employeeId);
	
	public void setEmployee(HashMap<Integer, Employee> hmap);
}
