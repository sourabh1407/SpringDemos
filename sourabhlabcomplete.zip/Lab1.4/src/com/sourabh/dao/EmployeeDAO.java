package com.sourabh.dao;

import java.util.HashMap;

import com.sourabh.bean.Employee;
import com.sourabh.collection.DBEmployee;

public class EmployeeDAO implements IEmployeeDAO {
	DBEmployee db ;
	HashMap<Integer, Employee> hmap =null;
	
	@Override
	public Employee getEmployee(int employeeId) {
		
		hmap= db.getHmap();
		Employee emp = hmap.get(employeeId);
		return emp;
	}

	@Override
	public void setEmployee(HashMap<Integer, Employee> hmap) {
	db.setHmap(hmap);	
		
	}

}
