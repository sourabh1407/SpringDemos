package com.sourabh.ui;

import com.sourabh.service.IEmployeeService;

public class Main {

	IEmployeeService empService;
	

}
