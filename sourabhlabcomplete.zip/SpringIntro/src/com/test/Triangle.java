package com.test;

import org.springframework.beans.factory.BeanNameAware;


public class Triangle implements BeanNameAware {
	
	public void init()
	{
		System.out.println("Init called");
	}

	public void destroy()
	{
		System.out.println("Destroy called");
	}

	public void draw()
	{
		System.out.println("Triangle draw ");
	}

	@Override
	public void setBeanName(String arg0) {
		System.out.println("Bean name aware name = "+arg0);
		
	}


	
}
