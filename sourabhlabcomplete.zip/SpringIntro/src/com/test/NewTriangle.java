package com.test;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class NewTriangle {
	
	@Autowired
	private Point point;
	
	@Autowired
	public NewTriangle(Point point) {
		super();
		System.out.println("inside constructor");
		this.point = point;
	}
	public NewTriangle() {
		super();
	}
	public Point getPoint() {
		return point;
	}
	//@Autowired
	public void setPoint(Point point) {
		System.out.println("inside setter");
		this.point = point;
	}

	public String getTriangleName() {
		return triangleName;
	}

	public void setTriangleName(String triangleName) {
		this.triangleName = triangleName;
	}

	@Value("Equilateral")
	private String triangleName;
	
	@PostConstruct
	public void init()
	{
		System.out.println("inside init");
	}
	
	public void draw()
	{
		System.out.println("Triangle draw "+triangleName);
		System.out.println(point.getX()+" "+point.getY());
	}
	
	@PreDestroy
	public void destroy()
	{
		System.out.println("Inisde destroy");
	}
}
