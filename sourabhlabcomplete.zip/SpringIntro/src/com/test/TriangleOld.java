package com.test;

public class TriangleOld {
	
	private int sides;
	private String triangleName;
	
	public TriangleOld() {
		super();
	}
	
	public TriangleOld(int sides, String triangleName) {
		super();
		this.sides = sides;
		this.triangleName = triangleName;
	}

	public int getSides() {
		return sides;
	}

	public void setSides(int sides) {
		this.sides = sides;
	}

	public String getTriangleName() {
		return triangleName;
	}

	public void setTriangleName(String triangleName) {
		this.triangleName = triangleName;
	}


	public void draw()
	{
		System.out.println("Triangle draw " + triangleName + " with sides " + sides);
	}
	
}
