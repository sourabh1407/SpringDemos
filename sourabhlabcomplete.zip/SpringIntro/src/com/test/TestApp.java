package com.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestApp {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("newspring.xml");
		NewTriangle obj = (NewTriangle)ctx.getBean("newTriangle");		
		obj.draw();

		ctx.close();
		
	}

}
