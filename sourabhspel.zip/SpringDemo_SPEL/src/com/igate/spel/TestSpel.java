package com.igate.spel;

import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpel {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		CityList city = (CityList)ctx.getBean("cityList");
		ArrayList<City> list=city.getCityList();
		
		for(City c:list)
		{
			System.out.println(c.getName()+" "+c.getPopulation()+" "+c.getState());
		}
		
		ArrayList<String> list1=city.getCityNames();
		
		for(String c:list1)
		{
			System.out.println(c);
		}
	}
	
}
