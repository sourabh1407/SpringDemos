package com.ems.service;

import java.util.List;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

public interface IEmployeeService {
	public int addEmployee(EmployeeBean bean)throws EmployeeException;
	
	public List<EmployeeBean> viewAllEmployees()throws EmployeeException;
	public boolean updateEmployee(int employeeId,double salary)throws EmployeeException;
	
	public boolean deleteEmployee(int employeeId)throws EmployeeException;
}
