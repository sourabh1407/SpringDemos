package com.ems.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id=0;
		
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id = bean.getEmployeeId();
		} catch (Exception e) {
			throw new EmployeeException("unable to persist in dao layer"+e.getMessage());
		}
		
		return id;
	}

	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		
		List<EmployeeBean> list =null;
		try {
			TypedQuery<EmployeeBean> qry = entityManager.createQuery("from EmployeeBean", EmployeeBean.class);
			list = qry.getResultList();
		} catch (Exception e) {
			throw new EmployeeException("unable to fetch records in dao "+e.getMessage() );
		}
		
		return list;
	}

	@Override
	public boolean updateEmployee(int employeeId, double salary)
			throws EmployeeException {
		try {
			EmployeeBean emp = entityManager.find(EmployeeBean.class, employeeId);
			if(emp != null)
			{
				emp.setEmployeeSalary(salary);
				entityManager.flush();
				return true;
			}
			else
			{
				return false;
			}
		} catch (Exception e) {
			throw new EmployeeException("error inside updateEmployee in dao layer "+e.getMessage());
		}
		
	}

	@Override
	public boolean deleteEmployee(int employeeId) throws EmployeeException {
		
		EmployeeBean emp = entityManager.find(EmployeeBean.class, employeeId);
		if(emp != null)
		{
			entityManager.remove(emp);
			return true;
		}
		else
		{
			return false;
		}
	}

}
