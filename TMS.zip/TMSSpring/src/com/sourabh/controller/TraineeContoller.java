package com.sourabh.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sourabh.bean.TraineeBean;
import com.sourabh.service.ITraineeService;
import com.sourabh.service.TraineeServiceImpl;

@Controller
public class TraineeContoller {
	
	@Autowired
	ITraineeService itrainee;



	public ITraineeService getItrainee() {
		return itrainee;
	}

	public void setItrainee(ITraineeService itrainee) {
		this.itrainee = itrainee;
	}

	@RequestMapping("/add")
	public String addT()
	{
		return ("addtrainee");
	}
	
	@RequestMapping("/insert")
	public void insertTrainee(@ModelAttribute("traineeBean")TraineeBean bean)
	{
		itrainee.addTrainee(bean);
		System.out.println("Added successfully");
	}
	
}
