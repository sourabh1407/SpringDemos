package com.sourabh.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sourabh.bean.TraineeBean;
import com.sourabh.exception.TmsException;
import com.sourabh.service.ITraineeService;
import com.sourabh.service.TraineeServiceImpl;

@Controller
public class TraineeContoller {
	
	@Autowired
	ITraineeService traineeService;



	public ITraineeService getItrainee() {
		return traineeService;
	}

	public void setItrainee(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@RequestMapping("/add")
	public String addT()
	{
		return ("addtrainee");
	}
	
	@RequestMapping("/insert")
	public ModelAndView insertTrainee(@ModelAttribute("traineeBean")TraineeBean bean)
	{	ModelAndView mv = new ModelAndView();
		
		try {
			traineeService.addTrainee(bean);
			mv.addObject("bean", bean);
			mv.setViewName("success");
		} catch (TmsException e) {
			System.out.println("Trainee addition exception ");
			mv.addObject("message","Trainee addition exception ");
			mv.setViewName("error");
		}
		
		System.out.println("Added successfully");
		return (mv);
	}
	
}
