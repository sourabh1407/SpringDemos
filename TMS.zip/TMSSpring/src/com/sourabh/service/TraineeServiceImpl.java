package com.sourabh.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sourabh.bean.TraineeBean;
import com.sourabh.dao.ITraineeDao;
import com.sourabh.dao.TraineeDaoImpl;

@Service
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	ITraineeDao tdao;



	public ITraineeDao getTdao() {
		return tdao;
	}



	public void setTdao(ITraineeDao tdao) {
		this.tdao = tdao;
	}



	@Override
	public void addTrainee(TraineeBean bean) {
		tdao.addTrainee( bean);
		
	}

}
