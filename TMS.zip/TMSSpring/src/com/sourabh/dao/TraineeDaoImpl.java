package com.sourabh.dao;

import java.util.HashMap;

import org.springframework.stereotype.Repository;

import com.sourabh.bean.TraineeBean;

@Repository
public class TraineeDaoImpl implements ITraineeDao {
	HashMap<Integer, TraineeBean> hmap = new HashMap<Integer, TraineeBean>() ;
	
	
	public HashMap<Integer, TraineeBean> getHmap() {
		return hmap;
	}


	public void setHmap(HashMap<Integer, TraineeBean> hmap) {
		this.hmap = hmap;
	}


	@Override
	public void addTrainee(TraineeBean bean) {
		
		hmap.put(bean.getTraineeId(), bean);
		System.out.println("Trainee added");
		
	}

}
