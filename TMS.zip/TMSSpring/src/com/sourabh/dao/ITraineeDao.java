package com.sourabh.dao;

import com.sourabh.bean.TraineeBean;

public interface ITraineeDao {
	
	public void addTrainee(TraineeBean bean);
	
	//public TraineeBean getTrainee(int traineeId);
	
	//public HashMap<Integer, TraineeBean> getAll();
	
	//public boolean deleteTrainee(int traineeId);
	
	//public boolean updateTrainee(int traineeId,TraineeBean bean);
	
}
